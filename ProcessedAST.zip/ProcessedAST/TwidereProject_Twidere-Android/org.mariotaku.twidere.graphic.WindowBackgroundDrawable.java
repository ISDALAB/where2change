window background drawabl 
window background drawabl draw set alpha set color filter get opac 
org mariotaku twider graphic android graphic canva android graphic color filter android graphic pixel format android graphic drawabl drawabl android support annot non null window background drawabl drawabl color window background drawabl color color color overrid draw non null canva canva canva draw color color overrid set alpha alpha overrid set color filter color filter color filter overrid get opac pixel format transluc 
creat mariotaku 