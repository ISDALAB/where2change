twider view util 
twider view util hit view 
org mariotaku twider util android support annot thread android view view twider view util twider view util thread hit view view view locat view get locat screen locat twider math util rang locat locat view get width twider math util rang inclus inclus twider math util rang locat locat view get height twider math util rang inclus inclus 
creat mariotaku 