recycl view accessor 
set layout posit 
android support widget recycl view accessor set layout posit recycl view view holder holder posit holder pre layout posit posit 
creat mariotaku 2016 