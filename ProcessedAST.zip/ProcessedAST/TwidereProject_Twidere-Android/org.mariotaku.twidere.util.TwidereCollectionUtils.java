twider collect util 
twider collect util string array 
org mariotaku twider util java util collect twider collect util twider collect util string string array collect list list length list size string string array string length idx object list string array idx pars util pars string string array 
creat mariotaku 