provid 
support 
org mariotaku twider util media preview provid android support annot non null android support annot nullabl android support annot worker thread org mariotaku restfu http rest http client org mariotaku twider model parcel media provid support non null string link nullabl parcel media non null string url nullabl worker thread parcel media non null string link non null rest http client client nullabl object extra 
creat mariotaku 