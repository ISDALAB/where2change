simpl text watcher 
text chang text chang text chang 
org mariotaku twider util view android text edit android text text watcher simpl text watcher text watcher overrid text chang char sequenc start count overrid text chang char sequenc start count overrid text chang edit 
creat mariotaku 2016 