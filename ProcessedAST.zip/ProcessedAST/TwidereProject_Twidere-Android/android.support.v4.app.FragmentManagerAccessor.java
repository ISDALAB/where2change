fragment manag accessor 
fragment manag accessor state save get layout inflat factori 
android support app android support view layout inflat factori fragment manag accessor fragment manag accessor state save fragment manag fragment manag impl fragment manag impl state save layout inflat factori get layout inflat factori fragment manag fragment manag impl fragment manag impl get layout inflat factori 
