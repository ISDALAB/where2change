twider type util 
twider type util simpl name build simpl name 
org mariotaku twider util java lang reflect parameter type java lang reflect type twider type util twider type util string simpl name type type string builder string builder build simpl name type string build simpl name type type string builder type class append class type get simpl name type parameter type build simpl name parameter type type get raw type append type arg parameter type type get actual type argument arg length append build simpl name arg append 
creat mariotaku 