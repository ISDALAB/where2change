favorit palett 
get particl color get circl color 
org mariotaku twider graphic like palett android anim argb evalu org mariotaku twider graphic like like anim drawabl favorit palett like anim drawabl palett argb evalu evalu argb evalu overrid get particl color count index progress integ evalu evalu progress overrid get circl color progress integ evalu evalu progress 
creat mariotaku 