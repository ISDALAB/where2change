photo statu updat 
photo statu updat set locat 
org mariotaku microblog librari fanfou model org mariotaku restfu http simpl valu map org mariotaku restfu http mime bodi photo statu updat simpl valu map photo statu updat bodi photo string statu put photo put statu set locat string locat locat remov put locat 
creat mariotaku 