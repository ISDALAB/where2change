non empti hash map 
put 
org mariotaku twider util collect java util hash map non empti hash map hash map overrid put key valu valu remov key put key valu 
creat mariotaku 2016 