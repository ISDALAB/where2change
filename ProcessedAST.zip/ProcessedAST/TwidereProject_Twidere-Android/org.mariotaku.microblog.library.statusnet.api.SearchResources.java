search resourc 
search status 
org mariotaku microblog librari statusnet api org mariotaku restfu annot method get org mariotaku restfu annot param queri org mariotaku microblog librari micro blog except org mariotaku microblog librari twitter model page org mariotaku microblog librari twitter model respons list org mariotaku microblog librari twitter model statu search resourc get respons list statu search status queri string queri queri page page micro blog except 
creat mariotaku 