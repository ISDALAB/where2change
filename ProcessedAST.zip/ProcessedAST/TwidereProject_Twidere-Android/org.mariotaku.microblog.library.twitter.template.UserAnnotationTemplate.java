user annot templat 
none 
org mariotaku microblog librari twitter templat org mariotaku restfu annot param key valu org mariotaku restfu annot param queri queri key valu key valu key key valu key valu key key valu key valu key key valu key valu key valu key valu user annot templat 
creat mariotaku 