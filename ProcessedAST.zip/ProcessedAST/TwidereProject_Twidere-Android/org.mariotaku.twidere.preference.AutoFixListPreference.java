auto fix list prefer 
auto fix list prefer auto fix list prefer set initi valu 
org mariotaku twider prefer android content context android content share prefer android prefer list prefer android util attribut set auto fix list prefer list prefer auto fix list prefer context context context auto fix list prefer context context attribut set attr context attr overrid set initi valu restor valu object default valu set initi valu restor valu default valu class cast except share prefer pref get share prefer pref pref edit remov get key appli 
