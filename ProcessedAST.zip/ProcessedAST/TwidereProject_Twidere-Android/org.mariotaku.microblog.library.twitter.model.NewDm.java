new 
set text set convers set media 
org mariotaku microblog librari twitter model org mariotaku restfu http simpl valu map new simpl valu map set text string text put text set convers string convers put convers set media media put media 
creat mariotaku 