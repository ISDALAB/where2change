favorit resourc 
creat fanfou favorit destroy fanfou favorit 
org mariotaku microblog librari fanfou api org mariotaku restfu annot method post org mariotaku restfu annot param path org mariotaku microblog librari micro blog except org mariotaku microblog librari twitter model statu favorit resourc post statu creat fanfou favorit path string micro blog except post statu destroy fanfou favorit path string micro blog except 
creat mariotaku 