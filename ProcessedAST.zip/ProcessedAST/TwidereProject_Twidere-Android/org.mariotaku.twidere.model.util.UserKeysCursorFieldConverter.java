user key cursor field convert 
new array pars item 
org mariotaku twider model util org mariotaku common objectcursor ab array cursor field convert org mariotaku twider model user key user key cursor field convert ab array cursor field convert user key overrid user key new array size user key size overrid user key pars item string user key valu 
creat mariotaku 