spannabl string builder support 
spannabl string builder support append 
org mariotaku twider util support android text spannabl string builder spannabl string builder support spannabl string builder support append spannabl string builder builder char sequenc text object span flag start builder length builder append text builder set span span start builder length flag 
creat mariotaku 