intern array util 
join 
org mariotaku microblog librari twitter util intern array util string join object array string separ string builder string builder array length append separ append array string 
creat mariotaku 