bearer author 
bearer author get header author 
org mariotaku microblog librari twitter auth org mariotaku restfu rest request org mariotaku restfu http author org mariotaku restfu http endpoint bearer author author string access token bearer author string access token access token access token overrid string get header endpoint endpoint rest request info access token overrid author access token 
creat mariotaku 