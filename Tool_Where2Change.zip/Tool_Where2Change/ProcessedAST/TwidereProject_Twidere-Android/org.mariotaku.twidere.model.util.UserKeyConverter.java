user key convert 
get string convert string 
org mariotaku twider model util com bluelinelab logansquar typeconvert string base type convert org mariotaku twider model user key user key convert string base type convert user key overrid user key get string string string string user key valu string overrid string convert string user key object object object string 
creat mariotaku 