twitter auth 
get applic access token 
org mariotaku microblog librari twitter org mariotaku restfu annot method post org mariotaku restfu annot param header org mariotaku restfu annot param key valu org mariotaku restfu annot param param org mariotaku microblog librari micro blog except org mariotaku microblog librari twitter auth auth get token header org mariotaku microblog librari twitter auth auth token twitter auth post param key valu key valu auth token get applic access token header auth get token header token micro blog except 
creat mariotaku 