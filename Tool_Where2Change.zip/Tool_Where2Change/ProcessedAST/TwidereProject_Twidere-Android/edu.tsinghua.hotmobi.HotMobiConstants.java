hot mobi constant 
none 
edu tsinghua hotmobi hot mobi constant string share prefer name string key fallback cach locat string key last upload time 
creat mariotaku 