filter subscript provid 
fetch filter first ad delet local data get user get keyword get sourc get link 
org mariotaku twider util filter android support annot nullabl org mariotaku twider model filter data java except java util list filter subscript provid fetch filter except first ad delet local data nullabl list filter data user item get user nullabl list filter data base item get keyword nullabl list filter data base item get sourc nullabl list filter data base item get link 
creat mariotaku 2017 