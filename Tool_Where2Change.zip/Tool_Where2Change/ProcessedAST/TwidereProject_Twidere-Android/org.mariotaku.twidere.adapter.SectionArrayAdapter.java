section array adapt 
section array adapt section array adapt 
org mariotaku twider adapt android content context java util collect section array adapt array adapt section array adapt context context layout re context layout re section array adapt context context layout re collect collect context layout re collect 
