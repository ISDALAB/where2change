like palett 
get particl color get circl color 
org mariotaku twider graphic like palett android anim argb evalu android graphic color org mariotaku twider graphic like like anim drawabl like palett like anim drawabl palett argb evalu evalu argb evalu hsv overrid get particl color count index progress degre count index hsv degre hsv hsv color hsv color hsv overrid get circl color progress integ evalu evalu progress 
creat mariotaku 