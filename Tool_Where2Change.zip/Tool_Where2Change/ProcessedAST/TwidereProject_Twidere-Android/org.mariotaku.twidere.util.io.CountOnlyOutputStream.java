count output stream 
write get count 
org mariotaku twider util java except java output stream count output stream output stream count overrid write except count get count count 
creat mariotaku 2016 