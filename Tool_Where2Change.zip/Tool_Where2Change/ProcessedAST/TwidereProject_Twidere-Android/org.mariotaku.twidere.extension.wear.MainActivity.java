main activ 
creat layout inflat 
org mariotaku twider extens wear android app activ android bundl android support wearabl view watch view stub android widget text view main activ activ text view text view overrid creat bundl save instanc state creat save instanc state set content view layout activ _main watch view stub stub watch view stub find view watch _view _stub stub set layout inflat listen watch view stub layout inflat listen overrid layout inflat watch view stub stub text view text view stub find view text 
