parameter express 
parameter express get paramet get sql 
org mariotaku twider model android support annot non null android support annot nullabl org mariotaku sqliteqb librari express parameter express express express string paramet parameter express non null express express nullabl string paramet express express paramet paramet string get paramet paramet string get sql express get sql 
creat mariotaku 